<div style="margin-right:10px;margin-top:10px; padding:5px;background-color : #FCFCFC;border:solid 1px #DFDFDF;">
	 <h3 style="margin:0;padding:0;">Need More Features?</h3>
	 <ul style="list-style-type:disc;margin-left:20px;">
		<li>Deliver Downloads from "Thank You" page </li>
		<li>Automatic Link Expiration </li>
		<li>Regenerate Download Link </li>
		<li>Multiple Files Upload per Product </li>
		<li>Product Bundling </li>
		<li>License Key Generation </li>
		<li>Allow Free Downloads </li>
		<li>Amazon S3 Integration </li>
		<li>Autoresponder</li>
		<li>iPhone Application </li>
		<li>Andriod App</li>
		<li>Google checkout</li>
		<li>Multiple tax & Shipping</li>
		<li>Inventory Tracking</li>
		<li>Order Management</li>
		<li>Great Support</li>
		<li>and more.. </li>
	 </ul>
	 <div style="text-align: center;">

		<h4>For Premium version: Please contact n.showket@gmail.com</h4>

	</div>
	<br/>
	<br>
	 <h3 style="margin:0;padding:0;">Shopping Cart For Photographers</h3>
	 <ul style="list-style-type:disc;margin-left:20px;">
		<li>Fully functional Shopping Cart plus special features for Photographers</li>
		<li>Bulk Image Upload</li>
		<li>Easy Gallery Management</li>
		<li>Gallery Category</li>
		<li>Sell both Digital Files & Prints</li>
		<li>Size Variations</li>
		<li>Price Variations</li>
		<li>Customizable Watermark</li>
		<li>Image preview in Lightbox</li>
		<li>and more...</li> 
	 </ul>
	 <div style="text-align: center;">

		<h4>For Premium version: Please contact n.showket@gmail.com</h4>

	</div>
	<br/>
	<br>
</div>																								
	<div style="margin-right:10px;margin-top:10px; padding:5px;background-color : #FCFCFC;border:solid 1px #DFDFDF;">
		<h3 style="margin:0;padding:0;">Get Support</h3>
		<ul>
			Please contact n.showket@gmail.com.
		</ul>
	</div>		