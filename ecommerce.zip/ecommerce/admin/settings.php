<?php
//$rate = new SimpleEcommCartTaxRate();
$setting = new EcommerceCartSetting();
$product_category = new EcommerceCartProductCategory();
$successMessage = '';
$versionInfo = false;
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if ($_POST['simpleecommcart-action'] == 'save rate') {
        $data = $_POST['tax'];
        if (isset($data['zip']) && !empty($data['zip'])) {
            list($low, $high) = explode('-', $data['zip']);
            if (isset($low)) {
                $low = trim($low);
            }
            if (isset($high)) {
                $high = trim($high);
            } else {
                $high = $low;
            }
            if (is_numeric($low) && is_numeric($high)) {
                if ($low > $high) {
                    $x = $high;
                    $high = $low;
                    $low = $x;
                }
                $data['zip_low'] = $low;
                $data['zip_high'] = $high;
            }
        }
        $rate->setData($data);
        $rate->save();
        $rate->clear();
        $successMessage = "Tax rate saved";
    } elseif ($_POST['simpleecommcart-action'] == 'saveOrderNumber' && SIMPLEECOMMCART_PRO) {
        $orderNumber = trim(EcommerceCartCommon::postVal('order_number'));
        EcommerceCartSetting::setValue('order_number', $orderNumber);
        $versionInfo = SimpleEcommCartProCommon::getVersionInfo();
        if ($versionInfo) {
            $successMessage = "Thank you! SimpleEcommCart has been activated.";
        } else {
            EcommerceCartSetting::setValue('order_number', '');
            $orderNumberFailed = true;
        }
    } elseif ($_POST['simpleecommcart-action'] == 'save product category') {
        $data = $_POST['product_category'];
        $product_category->setData($data);
        $product_category->save();
        $product_category->clear();
    }
} elseif (isset($_GET['task']) && $_GET['task'] == 'deleteTax' && isset($_GET['id']) && $_GET['id'] > 0) {
    $id = EcommerceCartCommon::getVal('id');
    $rate->load($id);
    $rate->deleteMe();
    $rate->clear();
} elseif (isset($_GET['task']) && $_GET['task'] == 'editProductCategory' && isset($_GET['id']) && $_GET['id'] > 0) {
    $id = EcommerceCartCommon::getVal('id');
    $product_category->load($id);
} elseif (isset($_GET['task']) && $_GET['task'] == 'deleteProductCategory' && isset($_GET['id']) && $_GET['id'] > 0) {
    $id = EcommerceCartCommon::getVal('id');
    $product_category->load($id);
    $product_category->deleteMe();
    $product_category->clear();
}
$cardTypes = EcommerceCartSetting::getValue('auth_card_types');
if ($cardTypes) {
    $cardTypes = explode('~', $cardTypes);
} else {
    $cardTypes = array();
}
?>

<?php if (!empty($successMessage)): ?>
  
<script type='text/javascript'>
  var $j = jQuery.noConflict();

  $j(document).ready(function() {
    setTimeout("$j('#SimpleEcommCartSuccessBox').hide('slow')", 2000);
  });
  
  <?php if ($versionInfo): ?>
    setTimeout("$j('.unregistered').hide('slow')", 1000);
  <?php
    endif; ?>
</script>
  
<div class='SimpleEcommCartSuccessModal' id="SimpleEcommCartSuccessBox" style=''>
  <p><strong><?php _e('Success', 'simpleecommcart'); ?></strong><br/>
  <?php echo $successMessage ?></p>
</div>


<?php
endif; ?> 

<h2><?php _e('Settings', 'simpleecommcart'); ?></h2>

<div id="saveResult"></div>
<div class='wrap' style="width:80%;max-width:80%;float:left;"> 
<div id="widgets-left" style="margin-right: 5px;">
  <div id="available-widgets">

	<!-- General Settings -->
	
	<!-- Product Categories -->
	<div class="widgets-holder-wrap">
    
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('Product Categories', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			<div style="padding-left:10px;">
			<h4>Add/Edit Category </h4>
		 	<form action="" method='post'>
            	<input type='hidden' name='simpleecommcart-action' value="save product category" />
			    <input type="hidden" name="product_category[id]" value="<?php echo $product_category->id ?>" />
				<table>
					<tr>
						<td>
							<?php _e('Category Name', 'simpleecommcart'); ?>
						</td>
						<td>
							<input type='text' name="product_category[name]" id="product_category_name" value='<?php echo $product_category->name ?>' />
						</td>
					</tr>
					<tr>
						<td>
							<?php _e('Description', 'simpleecommcart'); ?>
						</td>
						<td>  
							<textarea name="product_category[description]" id="product_category_description"  ><?php echo $product_category->description ?></textarea>
						</td>
					</tr>
					<tr>
						<td colspan="2">
						  <input type='submit' name='submit' class="button-primary"  value="Save Category" />
						</td>
					</tr>
				</table>
          	</form>
		</div>
		<div style="padding-left:10px;">
			<?php $product_categories = $product_category->getModels(); ?>
			<?php if (count($product_categories)): ?>
			 <h4>Category List </h4>
			 <table class="widefat" style='width: 500px; margin-bottom: 30px;'>
          		<thead>
          	<tr>
          		<th><?php _e('Category ID', 'simpleecommcart'); ?></th>
          		<th><?php _e('Category', 'simpleecommcart'); ?></th>
          		<th><?php _e('Description', 'simpleecommcart'); ?></th>
          		<th><?php _e('Actions', 'simpleecommcart'); ?></th>
          	</tr>
          </thead>
         		<tbody>
            <?php foreach ($product_categories as $category): ?> 
             <tr>
               <td><?php echo $category->id ?> </td>
			   <td><?php echo $category->name ?> </td>
			   <td><?php echo $category->description ?> </td>
               <td> 
				   <a href='?page=ecommercecart-settings&task=editProductCategory&id=<?php echo $category->id ?>'>Edit</a> | 
       <a class='delete' href='?page=ecommercecart-settings&task=deleteProductCategory&id=<?php echo $category->id ?>'>Delete</a>
               </td>
             </tr>
            <?php
    endforeach; ?>
          </tbody>
          	 </table>
          <?php
endif; ?>
		
      </div>
	  	</div>
	</div>
	
	<!-- Store and Page Settings -->
	<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('Store and Page Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
		<div style="padding-left:5px;">
			<form id="storeSettingsorm" class="ajaxSettingForm" action="" method='post'>
		    	<input type='hidden' name='action' value="save_settings" />
		        <input type='hidden' name='_success' value="Your store and page settings have been saved.">
					<h4>Store Page<img title="Store page where all your products are displayed under categories." src=" <?php echo INFO_ICON ?>"/></h4>
		            <ul> 
		              <li>
		                <label style="display: inline-block; width: 120px; text-align: right;">Main store page:</label> 
						<select id="main_store_page" name="main_store_page">
		                  <?php
global $wpdb;
$post_table = $wpdb->base_prefix . "posts";
$pages = $wpdb->get_results("SELECT * from $post_table where post_type='page'");
foreach ($pages as $page) {
    if (EcommerceCartSetting::getValue('main_store_page') == NULL && $page->post_title == 'Store') {
        echo '<option value="' . $page->ID . '" selected="selected">' . $page->post_title . '</option>';
    } else if (EcommerceCartSetting::getValue('main_store_page') == $page->ID) {
        echo '<option value="' . $page->ID . '" selected="selected">' . $page->post_title . '</option>';
    } else {
        echo '<option value="' . $page->ID . '">' . $page->post_title . '</option>';
    }
}
?>
						</select> 
						<img title="The page will be used as store page. By default plugin creates a store page. If  a different page is selected then add this shortcode to that page: [simpleecommcart_store_home]" src=" <?php echo INFO_ICON ?>"/>
		              </li>
					   <li>
		                <label style="display: inline-block; width: 120px; text-align: right;">Display Products:</label> 
						<select id="display_products" name="display_products" style="width:100px;">
		                   <option  value="grid" <?php echo EcommerceCartSetting::getValue('display_products') == 'grid' ? 'selected="selected"' : '' ?> >Grid</option>
						    <option  value="list" <?php echo EcommerceCartSetting::getValue('display_products') == 'list' ? 'selected="selected"' : '' ?> >List</option>
						</select> 
						<img title="Products in the store page can be displayed either list view or grid view." src=" <?php echo INFO_ICON ?>"/>
		              </li>
					</ul>

					<!--<h4>Checkout Page</h4>
		            <ul> 
		              <li>
		                <label style="display: inline-block; width: 120px; text-align: right;">Checkout page:</label> 
						<select id="checkout_page" name="checkout_page">
		                  <?php
global $wpdb;
$post_table = $wpdb->base_prefix . "posts";
$pages = $wpdb->get_results("SELECT * from $post_table where post_type='page'");
foreach ($pages as $page) {
    if (EcommerceCartSetting::getValue('checkout_page') == NULL && $page->post_title == 'Checkout') {
        echo '<option value="' . $page->ID . '" selected="selected">' . $page->post_title . '</option>';
    } else if (EcommerceCartSetting::getValue('checkout_page') == $page->ID) {
        echo '<option value="' . $page->ID . '" selected="selected">' . $page->post_title . '</option>';
    } else {
        echo '<option value="' . $page->ID . '">' . $page->post_title . '</option>';
    }
}
?>
						</select> 
		              </li> 
					</ul>-->
					
					<h4>Landing Page/'Thank you' Page <img title="Landing page where customers get redirected after a successful purchase." src=" <?php echo INFO_ICON ?>"/></h4>
		            <ul> 
		              <li>
		                <label style="display: inline-block; width: 120px; text-align: right;">Landing page:</label> 
						<select id="landing_page" name="landing_page">
		                  <?php
global $wpdb;
$post_table = $wpdb->base_prefix . "posts";
$pages = $wpdb->get_results("SELECT * from $post_table where post_type='page'");
foreach ($pages as $page) {
    if (EcommerceCartSetting::getValue('landing_page') == $page->ID) {
        echo '<option value="' . $page->ID . '" selected="selected">' . $page->post_title . '</option>';
    } else {
        echo '<option value="' . $page->ID . '">' . $page->post_title . '</option>';
    }
}
?>
						</select> 
						<img title="The page will be used as Landing page." src=" <?php echo INFO_ICON ?>"/>
		              </li> 
					</ul>
					<h4>Terms and Condition</h4>
		            <ul> 
					 <li>
		                <label style="display: inline-block; width: 120px; text-align: right;">Terms & Conditions:</label> 
						<select id="terms_and_condition" name="terms_and_condition" style="width:100px;">
		                   <option  value="yes" <?php echo EcommerceCartSetting::getValue('terms_and_condition') == 'yes' ? 'selected="selected"' : '' ?> >Yes</option>
						    <option  value="no" <?php echo EcommerceCartSetting::getValue('terms_and_condition') == 'no' ? 'selected="selected"' : '' ?> >No</option>
						</select> 
						<img title="Select “NO” if you don’t wish to provide Terms and Conditions. If Selected “Yes” customer will be able to view Terms and conditions link on the cart page before payment." src=" <?php echo INFO_ICON ?>"/>
		              </li>
		              <li>
		                <label style="display: inline-block; width: 120px; text-align: right;">Terms & Conditions Page:</label> 
						<select id="terms_and_condition_page" name="terms_and_condition_page">
		                  <?php
global $wpdb;
$post_table = $wpdb->base_prefix . "posts";
$pages = $wpdb->get_results("SELECT * from $post_table where post_type='page'");
foreach ($pages as $page) {
    if (EcommerceCartSetting::getValue('terms_and_condition_page') == $page->ID) {
        echo '<option value="' . $page->ID . '" selected="selected">' . $page->post_title . '</option>';
    } else {
        echo '<option value="' . $page->ID . '">' . $page->post_title . '</option>';
    }
}
?>
						</select> 
						<img title="This page will be used as Terms and Condition page. " src=" <?php echo INFO_ICON ?>"/>
		              </li>
					  
					</ul>

					<ul>
					 <li>
		                <label style="display: inline-block; width: 120px; text-align: right;" >&nbsp;</label>
		                <input type='submit' name='submit' class="button-primary" style='width: 60px;' value="Save" />
		              </li>
					</ul>
				</form>
			</div>
	  	</div>
	</div>
	
	<!-- Email & Text Notification Settings -->
	<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('Email Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			<form id="emailReceiptForm" class="ajaxSettingForm" action="" method='post'>
            <input type='hidden' name='action' value="save_settings" />
            <input type='hidden' name='_success' value="The email & text notification settings have been saved.">
            <ul>
 				<li><label style="display: inline-block; width: 120px; text-align: right;" for='email_from_address'><?php _e('Email Address', 'simpleecommcart'); ?>:</label>
              <input type='text' name='email_from_address' id='email_from_address' style='width: 375px;' 
              value="<?php echo EcommerceCartSetting::getValue('email_from_address'); ?>" />
              
              </li>
              <li><label style="display: inline-block; width: 120px; text-align: right;" for='email_from_name'><?php _e('Email From', 'simpleecommcart'); ?>:</label>
              <input type='text' name='email_from_name' id='email_from_name' style='width: 375px;' 
              value="<?php echo EcommerceCartSetting::getValue('email_from_name', true); ?>" />
              </li> 
            </ul>
			
			<table>
				<tr>
				<td colspan="2">
						<h4><input type="checkbox" name="email_sent_on_purchase" <?php echo (EcommerceCartSetting::getValue('email_sent_on_purchase') == 'on') ? 'checked="checked"' : '' ?>/>Email Sent on Purchase</h4>
				</td>
			</tr>				
				<tr>
				<td>
				 <label style="display: inline-block; width: 120px; text-align: right;" for='email_sent_on_purchase_subject'><?php _e('Email Subject', 'simpleecommcart'); ?>:</label>
				</td>
				<td>
			<input type='text' name='email_sent_on_purchase_subject' id='email_sent_on_purchase_subject' value="<?php echo EcommerceCartSetting::getValue('email_sent_on_purchase_subject'); ?>" /> 			</td>
			</tr>						
				<tr>
			<td><label style="display: inline-block; width: 120px; text-align: right;" for='email_sent_on_purchase_body'><?php _e('Email Body', 'simpleecommcart'); ?>:</label>
			</td>
			
			<td>
			   <textarea  style="text-align:left;" rows="5" cols="100"    name='email_sent_on_purchase_body' id='email_sent_on_purchase_body'><?php echo EcommerceCartSetting::getValue('email_sent_on_purchase_body', true); ?></textarea>
			</td>
			</tr>									
			</table> 
			 
			<!--<table>
				<tr>
				<td colspan="2">
					<h4> Email Sent when Order Pending</h4>
					<h3>This is only available in Simple eCommerce Premium version.</h3>
				</td>
			</tr>				
				 								
			</table> 
			
			<table>
				<tr>
					<td colspan="2">
							<h4> Email Sent when Shipped</h4>
							<h3>This is only available in Simple eCommerce Premium version.</h3>
					</td>
				</tr> 							
			</table> 
			
			<table>
				<tr>
				<td colspan="2">
						<h4> Email Sent on refund</h4>
						<h3>This is only available in Simple eCommerce Premium version.</h3>
				</td>
			</tr>				
			 								
			</table>
					 -->
			<table>
				<tr>
				<td>
						<h4><input type="checkbox" name="email_signature" <?php echo (EcommerceCartSetting::getValue('email_signature') == 'on') ? 'checked="checked"' : '' ?>/>Email Signature</h4>
				</td>
				<td>
					<input type='text' name='email_signature_text' id='email_signature_text' value="<?php echo EcommerceCartSetting::getValue('email_signature_text'); ?>" /> 
				</td>
			</tr>	 		
			</table> 
					 
			<ul>    
				<li><label style="display: inline-block; width: 120px; text-align: right;" for='submit'>&nbsp;</label>	
				<input type='submit' name='submit' class="button-primary" style='width: 60px;' value="Save" /></li>
			 </ul>
          </form>
	  	</div>
	</div>

<!-- Amazon S3 Settings -->
<!--<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('Amazon S3 Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			 <h2 style="font-weight:normal;">This feature is available in Simple eCommerce Premium Version</h2>
        
	  	</div>
	</div>-->

<!-- Webservice for iPhone Settings  -->
<!--<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('Webservice for iPhone Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			 <h2 style="font-weight:normal;">This feature is available in Simple eCommerce Premium Version</h2>
        
	  	</div>
	</div>

	-->
<!-- 	
	<!-- Testing and Debugging -->
	
<!--<h3>3rd Party Integration</h3>-->
<!-- AWeber Settings   -->
<!--<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('AWeber Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			 <h2 style="font-weight:normal;">This feature is available in Simple eCommerce Premium Version</h2>
        
	  	</div>
	</div>-->
	
	<!-- MailChimp Settings    -->
<!--<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('MailChimp Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			 <h2 style="font-weight:normal;">This feature is available in Simple eCommerce Premium Version</h2>
        
	  	</div>
	</div>-->
	
	<!-- GetResponse Settings    -->
<!--<div class="widgets-holder-wrap closed">
    	<div class="sidebar-name">
        	<div class="sidebar-name-arrow"><br/></div>
        		<h3><?php _e('GetResponse Settings', 'simpleecommcart'); ?> <span><img class="ajax-feedback" alt="" title="" src="images/wpspin_light.gif"/></span></h3>
      	</div>
      	<div class="widget-holder">
			 <h2 style="font-weight:normal;">This feature is available in Simple eCommerce Premium Version</h2>
        
	  	</div>
	</div>-->
	
  </div>
</div>
</div>
<div style="float:right;width:18%;max-width:18%">
	<?php
echo EcommerceCartCommon::getView('admin/more.php', NULL);
?>
</div>
<div style="clear:both;"/>
 

<script type='text/javascript'>
  $jq = jQuery.noConflict();
  
  $jq(document).ready(function() {
    $jq(".multiselect").multiselect({sortable: true});
    
    $jq('.sidebar-name').click(function() {
     $jq(this.parentNode).toggleClass("closed");
    });
    
    $jq("#continue_shopping").val("<?php echo EcommerceCartSetting::getValue('continue_shopping'); ?>");

    $jq('#international_sales_yes').click(function() {
     $jq('#eligible_countries_block').show();
    });

    $jq('#international_sales_no').click(function() {
     $jq('#eligible_countries_block').hide();
    });

    if($jq('#international_sales_no').attr('checked')) {
     $jq('#eligible_countries_block').hide();
    }
    
    $jq("#html_yes").change(function(){
      if($jq(this).attr('checked')){
        $jq("#html_editor").show();
      }
    })
    $jq("#html_no").change(function(){
      if($jq(this).attr('checked')){
        $jq("#html_editor").hide();
      }
    })
    
    $jq('#auth_url').change(function() {
      setGatewayDisplay();
    });
    
    <?php if ($authUrl = EcommerceCartSetting::getValue('auth_url')): ?>
        $jq('#auth_url').val('<?php echo $authUrl; ?>').attr('selected', true);
    <?php
endif; ?>
    
    setGatewayDisplay();
    function setGatewayDisplay() {
      if($jq('#auth_url').val() == 'other') {
        $jq('#emulation_url_item').css('display', 'inline');
      }
      else {
        $jq('#emulation_url_item').css('display', 'none');
      }
      
      if($jq('#auth_url :selected').text() == 'Authorize.net Test'){
        $jq("#authorizenetTestMessage").show();
      }
      else{
        $jq("#authorizenetTestMessage").hide();
      }
      
      if($jq('#auth_url :selected').text() == 'Authorize.net' || $jq('#auth_url :selected').text() == 'Authorize.net Test') {
        $jq('#authnet-image').css('display', 'block');
      }
      else {
        $jq('#authnet-image').css('display', 'none');
      }
    }
	generateCommaSeparatedCountryList();
    $jq('.targetmarketselect').change(function(){
		generateCommaSeparatedCountryList();
	});
	$jq('#selectAll').click(function(){
		$jq('.targetmarketselect').each(function(){
		  $jq(this).attr('checked','checked');
		});
		generateCommaSeparatedCountryList();
	});
	$jq('#selectNone').click(function(){
		$jq('.targetmarketselect').each(function(){
		  $jq(this).removeAttr('checked','checked');
		});
		generateCommaSeparatedCountryList();
	});
  });
  
  function generateCommaSeparatedCountryList()
  {
  	var str="";
  	$jq('.targetmarketselect').each(function(){
		if( $jq(this).attr('checked') =='checked')
		{
			var val = $jq(this).val();
			str+=","+val;
		} 
	});
	str = str.substring(1);
	//alert(str);
	$jq('#hdnCountries').val(str);
  }
  
</script>
