<?php
/**
 * Exception error codes
 * 66101 - Product file upload failed
 * 66102 - Product save failed 
 * 66201 - SimpleEcommCartConstantContact failed to initialize
 */ 

class EcommerceCartException extends Exception {}